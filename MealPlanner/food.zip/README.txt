# Fall 2018 Team Project: Food Query and Meal Analyzer

## A-Team 43

## Team Members

* Huifeng Su(hsu56@wisc.edu)
* Junheng Wang(jwang922@wisc.edu)
* Yuhao Liu(liu697@wisc.edu)
* Ruijian Huang(rhuang76@wisc.edu)
* Leon Zhang(jzhang867@wisc.edu)

## Team Size: 5